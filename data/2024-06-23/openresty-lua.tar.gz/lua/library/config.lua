local _M = {}
local dkjson = require "dkjson"
local json = require "json"


_M["config"] = {}

--获取当前路径
function _M.home_path()
    local current_script_path = debug.getinfo(1, "S").source:sub(2)
    local home_path = current_script_path:sub(1, 0 - string.len("/lua/library/config.lua") - 1)
    return home_path
end

--加载配置文件
function _M.load_from_file()

    local home_path = _M.home_path()

    -- 定义配置文件table
    configFiles = {
        app = home_path .. "/config/application.json",
        filter_rule = home_path .. "/config/rules/filter.json",
        frequency_limit_rule = home_path .. "/config/rules/frequency_limit.json",
    }
    for key, filepath in pairs(configFiles) do

        -- 读取配置文件
        local file = io.open(filepath, "r")
        if file == nil then
            ngx.log(ngx.STDERR, 'config file not found')
            ngx.exit(500)
        end
        local data = file:read("*all");
        _M["config"][key] = dkjson.decode(data)
        file:close();
    end
end


-- 获取配置信息, 支持多维度"key.array.name"形式获取配置
function _M.get(key)
    if string.find(key, ".") == nil then
        return _M["config"][key]
    else
        local keys = key:split(".")
        local temp = _M["config"]
        for i = 1, #keys do
            temp = temp[keys[i]]
        end
        return temp
    end
end

_M.load_from_file()
return _M
