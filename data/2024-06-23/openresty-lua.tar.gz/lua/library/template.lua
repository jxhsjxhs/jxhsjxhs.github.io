local json = require "json"
local config = require "config"

local _M = {}
_M["tpls"] = {}

--加载模板文件
local function load_from_file(filepath)
    local key = ngx.md5(filepath);
    if not _M.tpls[key] then
        local file = io.open(filepath, "r")
        if file == nil then
            return json.encode({ ["ret"] = "error", ["msg"] = "template file not found" })
        end
        _M.tpls[key] = file:read("*all");
        file:close();
    end

    return _M.tpls[key]
end

--渲染模板
function _M.render(self, filename, status)
    if status == nil then
        status = ngx.HTTP_OK
    end
    local filepath = config.home_path() .. "/lua/template/" .. filename .. ".html"
    local content = load_from_file(filepath)
    ngx.status = status
    ngx.header.content_type = "text/html"
    ngx.say(content)
    ngx.exit(ngx.HTTP_OK)
end

return _M
