local json = require "json"
local config = require "config"

local _M = {}


function _M.string_replace(s, pattern, replace, times)
    local ret = nil
    while times >= 0 do
        times = times - 1
        local s_start, s_stop = string.find(s, pattern, 1, true) -- 1,true means plain searches from index 1
        if s_start ~= nil and s_stop ~= nil then
            s = string.sub(s, 1, s_start - 1) .. replace .. string.sub(s, s_stop + 1)
        end
    end
    return s
end

function _M.existed(list, value)
    for idx, item in ipairs(list) do
        if item == value then
            return true
        end
    end
    return false
end

function _M.ngx_ctx_dump()
    local dump_str = json.encode(ngx.ctx)
    ngx.var.ae_ctx_dump = dump_str
end

function _M.ngx_ctx_load()

    if ngx.var.ae_ctx_dump == nil then
        return
    end

    local dump_str = ngx.var.ae_ctx_dump
    if dump_str ~= '' then
        ngx.ctx = json.decode(dump_str)
    end
end

function _M.get_request_args()
    local args = ngx.req.get_uri_args()
    local post_args, err = nil

    ngx.req.read_body()
    post_args, err = ngx.req.get_post_args()
    if post_args == nil then
        return args
    end

    for k, v in pairs(post_args) do
        args[k] = v
    end

    return args
end

function _M.get_request_args()
    local args = ngx.req.get_uri_args()
    local post_args, err = nil

    ngx.req.read_body()
    post_args, err = ngx.req.get_post_args()
    if post_args == nil then
        return args
    end

    for k, v in pairs(post_args) do
        args[k] = v
    end

    return args
end

-- 扩展string split函数
function string:split(sep)
    local sep, fields = sep or ":", {}
    local pattern = string.format("([^%s]+)", sep)
    self:gsub(pattern, function(c) fields[#fields + 1] = c end)
    return fields
end

-- 获取真实ip
function _M.get_client_ip()
    local header_table = ngx.req.get_headers();
    local args = config.get("app.header_ip_args");
    for i = 1, #(args) do
        if args[i] == "remote_addr" then
            if ngx.var.remote_addr ~= nil then
                return ngx.var.remote_addr
            end
        elseif header_table[args[i]] ~= nil then

            local ip = header_table[args[i]]:split(',')[1];
            if ip ~= nil and ip ~= "-" then
                return ip;
            end
        end
    end
    return nil;
end

return _M
