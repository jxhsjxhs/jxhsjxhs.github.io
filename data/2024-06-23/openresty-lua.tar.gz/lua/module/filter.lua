local _M = {}

local config = require "config"
local request_matcher = require "request_matcher"
local template = require "template"

--过滤器
function _M.filter()


    if config.get("app.filter_enable") ~= true then
        return
    end

    for i = 1, #(config.get("filter_rule")) do
        local rule = config.config["filter_rule"][i]
        local enable = rule['enable']
        local matcher = rule['matchers']
        if enable == true and request_matcher.test(matcher) == true then
            ngx.log(ngx.ERR, "Access Deny")
            if config.get("app.debug_model") == true then
                return;
            end
            return template:render("access_deny")
        end
    end
end

return _M
