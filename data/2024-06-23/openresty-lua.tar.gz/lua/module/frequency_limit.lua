local config = require "config"
local request_matcher = require "request_matcher"
local util = require "util"
local template = require "template"

local _M = {}
local limit_dict = ngx.shared.frequency_limit

function _M.filter()

    if config.get("app.frequency_limit_enable") ~= true then
        return
    end

    for i = 1, #(config.get("frequency_limit_rule")) do
        local rule = config.config["frequency_limit_rule"][i]
        local enable = rule['enable']
        local matcher = rule['matchers']

        if enable == true and request_matcher.test(matcher) == true then
            local key = i;
            for idx, item in ipairs(rule['limit_items']) do
                if item == 'ip' then
                    local client_ip = util.get_client_ip();
                    if client_ip == nil then
                        ngx.log(ngx.WARN, "Frequency Limit：can't find the IP from the header")
                        return;
                    end
                    key = key .. '-' .. client_ip
                elseif item == 'uri' then
                    key = key .. '-' .. ngx.var.uri
                elseif string.find(item, "param=") == 1 then
                    local keys = item:split("=");
                    local args_table = util.get_request_args()
                    if args_table[keys[2]] ~= nil then
                        key = key .. '-' .. args_table[keys[2]]
                    end
                elseif item == 'token' then
                    local header_table = ngx.req.get_headers()
                    if header_table["token"] ~= nil then
                        key = key .. '-' .. header_table["token"]
                    end
                end
            end

            if key == i or key == '' or key == nil then
                return;
            end

            local time = rule['time']
            local count = rule['count']
            if tonumber(count) == 0 then
                return;
            end

            local count_now = limit_dict:get(key)
            --ngx.log(ngx.STDERR, tonumber(count_now) );

            if count_now == nil then
                if tonumber(time) <= 0 then
                    time = 1;
                end
                limit_dict:set(key, 1, tonumber(time))
                count_now = 1
            end

            limit_dict:incr(key, 1)
            ngx.status = ngx.HTTP_OK
            if count_now > tonumber(count) then
                ngx.log(ngx.ERR, "Frequency Limit：too many requests，key=" .. key);
                if config.get("app.debug_model") == true then
                    return;
                end
                local status_code = config.get("app.frequency_limit_status_code");
                return template:render("frequency_limit", status_code);
            end

            return
        end
    end
end

return _M
