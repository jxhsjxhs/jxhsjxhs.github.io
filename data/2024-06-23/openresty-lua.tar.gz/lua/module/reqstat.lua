-- -*- coding: utf-8 -*-
local json = require "json"
local config = require "config"
local util = require "util"

local _M = {}

-- 生成key
function genKey(key, host)
    if host == nil then
        host = ngx.var.host
    end

    return key .. "@" .. host;
end

-- 自增统计值
function incrValue(key, value)
    key = genKey(key);
    if ngx.shared.summary:get(key) == nil then
        ngx.shared.summary:set(key, 0)
    end
    ngx.shared.summary:incr(key, value)
end

-- 设置值
function setValue(key, value)
    key = genKey(key);
    ngx.shared.summary:set(key, value)
end

-- 获取统计值
function getValue(key, host)
    key = genKey(key, host);
    return ngx.shared.summary:get(key) or 0
end


function _M.log()
    if config.get("app.reqstat_enable") ~= true then
        return
    end


    local status_code = ngx.var.status;
    incrValue("http_" .. status_code, 1);

    local status_pre = string.sub(status_code, 1, 1);
    if status_pre == "1" then
        incrValue("http_1xx", 1);
    elseif status_pre == "2" then
        incrValue("http_2xx", 1);
    elseif status_pre == "3" then
        incrValue("http_3xx", 1);
    elseif status_pre == "4" then
        incrValue("http_4xx", 1);
    elseif status_pre == "5" then
        incrValue("http_5xx", 1);
    else
        incrValue("http_other_status", 1);
    end

    incrValue("req_total", 1);
    incrValue("bytes_in", ngx.var.request_length);
    incrValue("bytes_out", ngx.var.bytes_sent);
    incrValue("req_time_total", ngx.var.request_time);
    if config.get("app.reqstat_timeout") ~= 0 and tonumber(ngx.var.request_time) >= config.get("app.reqstat_timeout") then
        incrValue("req_timeout_total", ngx.var.request_time);
    end

    -- 判断是否upstream请求
    if ngx.var.upstream_addr ~= nil then
        incrValue("ups_req_total", 1);
        if ngx.var.upstream_response_time ~= nil then
            local ups_time = tonumber(ngx.var.upstream_response_time)
            incrValue("ups_time_total", ups_time or 0);
        end

        local ups_status_code = ngx.var.upstream_status;

        local ups_status_pre = string.sub(ups_status_code, 1, 1);
        if ups_status_pre == 4 then
            incrValue("http_ups_4xx", 1);
        end
        if ups_status_pre == 5 then
            incrValue("http_ups_5xx", 1);
        end
    end
end

function _M.report()
    local dict = ngx.shared.summary;
    local keys = dict:get_keys(0);
    local report = {};
    for i, key in pairs(keys) do
        local name = key:split("@");
        local parm = name[1];
        local host = name[2];
        if parm ~= nil and host ~= nil then
            if report[host] == nil then
                report[host] = {};
            end
        end
    end

    for host, value in pairs(report) do
        report[host] = {}
        report[host]["server_name"] = host;

        report[host]["req"] = {}
        report[host]["req"]["bytes_in"] = getValue("bytes_in", host);
        report[host]["req"]["bytes_out"] = getValue("bytes_out", host);
        report[host]["req"]["req_total"] = getValue("req_total", host);
        report[host]["req"]["req_time_total"] = getValue("req_time_total", host);
        report[host]["req"]["req_timeout_total"] = getValue("req_timeout_total", host);


        report[host]["status"] = {}
        report[host]["status"]["http_1xx"] = getValue("http_1xx", host);
        report[host]["status"]["http_2xx"] = getValue("http_2xx", host);
        report[host]["status"]["http_3xx"] = getValue("http_3xx", host);
        report[host]["status"]["http_4xx"] = getValue("http_4xx", host);
        report[host]["status"]["http_5xx"] = getValue("http_5xx", host);
        report[host]["status"]["http_other_status"] = getValue("http_other_status", host);
        report[host]["status"]["http_200"] = getValue("http_200", host);
        report[host]["status"]["http_206"] = getValue("http_206", host);
        report[host]["status"]["http_302"] = getValue("http_302", host);
        report[host]["status"]["http_304"] = getValue("http_304", host);
        report[host]["status"]["http_403"] = getValue("http_403", host);
        report[host]["status"]["http_404"] = getValue("http_404", host);
        report[host]["status"]["http_410"] = getValue("http_410", host);
        report[host]["status"]["http_416"] = getValue("http_416", host);
        report[host]["status"]["http_499"] = getValue("http_499", host);
        report[host]["status"]["http_500"] = getValue("http_500", host);
        report[host]["status"]["http_502"] = getValue("http_502", host);
        report[host]["status"]["http_503"] = getValue("http_503", host);
        report[host]["status"]["http_504"] = getValue("http_504", host);
        report[host]["status"]["http_508"] = getValue("http_508", host);

        local status_code = config.get("app.frequency_limit_status_code");
        local key = "http_" .. status_code;
        if status_code ~= nil and report[host]["status"][key] == nil then
            report[host]["status"][key] = getValue(key, host);
        end

        report[host]["upstream"] = {};
        report[host]["upstream"]["ups_req_total"] = getValue("ups_req_total", host);
        report[host]["upstream"]["ups_req_time_total"] = getValue("ups_time_total", host);
        report[host]["upstream"]["ups_http_4xx"] = getValue("http_ups_4xx", host);
        report[host]["upstream"]["ups_http_5xx"] = getValue("http_ups_5xx", host);
    end

    return json.encode(report)
end



function _M.clear()
    ngx.shared.summary:flush_all()
    return '{}'
end

return _M
