-- -*- coding: utf-8 -*-
local reqstat = require "reqstat"
local config = require "config"
local json = require "json"
local util = require "util"

local _M = {}

_M.url_route = {}
_M.mime_type = {}
_M.mime_type['.js'] = "application/x-javascript"
_M.mime_type['.css'] = "text/css"
_M.mime_type['.html'] = "text/html"

-- 检测ip权限
function checkIpPermission()
    local allow_ip = config.get('app.api_allow_ip');
    if allow_ip ~= '*' then
        local client_ip = ngx.var.remote_addr;
        local ips = allow_ip:split(",");
        local is_allow = false;
        for i, ip in pairs(ips) do
            if client_ip == ip then
                is_allow = true;
            end
        end
        if is_allow == false then
            local info = json.encode({ ["ret"] = "failed", ["message"] = "no permissions" })
            ngx.status = 403
            ngx.header.content_type = "application/json"
            ngx.say(info)
            ngx.exit(ngx.HTTP_OK)
        end
    end
end

function _M.filter()

    local method = ngx.req.get_method()
    local uri = ngx.var.uri
    local api_uri = config.get('app.api_uri')
    local host = config.get('app.api_host')

    if host ~= '' then
        if ngx.var.host ~= host then
            return
        end
    end

    if string.find(uri, api_uri) == 1 then
        checkIpPermission();
        local path = string.sub(uri, string.len(api_uri) + 1)
        for i, item in ipairs(_M.route_table) do
            ngx.header.content_type = "application/json"
            if method == item['method'] and path == item['path'] then
                ngx.header.content_type = "application/json"
                ngx.header.charset = "utf-8"

                ngx.say(item['handle']())
                ngx.exit(ngx.HTTP_OK)
            end
        end
    end
end

_M.route_table = {
    { ['method'] = "GET", ["path"] = "/reqstat", ['handle'] = reqstat.report },
    { ['method'] = "POST", ["path"] = "/status/clear", ['handle'] = reqstat.clear },
}

return _M