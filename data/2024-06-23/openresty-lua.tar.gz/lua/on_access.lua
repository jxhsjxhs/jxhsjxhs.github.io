local filter = require "filter"
local frequency_limit = require "frequency_limit"
local router = require "router"

if ngx.var.ae_exec_flag and ngx.var.ae_exec_flag ~= '' then
   return
end

filter.filter()
frequency_limit.filter()
router.filter()
