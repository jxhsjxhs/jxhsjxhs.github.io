local reqstat = require "reqstat"
reqstat.log()